package com.eclipse;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1{

	
	@Test
	public void testlogin1()
	{
		Dev mytest = new Dev();
		Assert.assertEquals(0,mytest.userLogin("abc","abc123"));
	}
	
	@Test
	public void testlogin2()
	{
		Dev mytest = new Dev();
		Assert.assertEquals(1,mytest.userLogin("abc","abc@123"));
	}
}
