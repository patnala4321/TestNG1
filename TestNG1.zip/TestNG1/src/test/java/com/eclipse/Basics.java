package com.eclipse;

import org.testng.annotations.Test;

public class Basics {
	
	
	@Test
	public void demo()
	{
		System.out.println("Hello");
	}
	
	@Test
	public void SecondTest()
	{
		System.out.println("Hi");
	}
}
