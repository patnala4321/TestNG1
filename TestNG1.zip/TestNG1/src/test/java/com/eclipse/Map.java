package com.eclipse;

public class Map {

}
